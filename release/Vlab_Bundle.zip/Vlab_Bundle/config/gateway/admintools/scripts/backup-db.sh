pg_dumpall > dump.`date +%F.%T`.sc

