svn export --force https://128.238.66.6/svn/repos/vlab/branch/interim/www /var/www/localhost/htdocs_ssl/interim
