cd /var/www/localhost
tar cjf /root/bak/htdocs-`date +%y:%m:%d:%T`.tar.bz2 htdocs_ssl
