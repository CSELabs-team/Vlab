#!/bin/bash
echo $1
ssh $1 xm list

