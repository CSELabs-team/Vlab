<?php include('vlab-header.inc'); ?>

<h3>Enter Username</h3>
<form name="input" action="GetUserInfo.php" method="POST">
Username: <br />
<input type="text" name="username"  /> <br><p>
<input type="submit" value="SUBMIT"  />
</form>

<?php include('vlab-footer.inc'); ?>

