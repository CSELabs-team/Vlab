<?php include('vlab-header.inc'); ?>
		
<h3 align=left>Info</h3>	
		<table width='90%'>
			<tr><td> <a href="UserInfo.php">User Info</a></td>
			<tr><td> <a href="ClassInfo.php">Class Info</a></td>
		</table>
<h3 align=left>Base Image</h3>
		<table width='90%'>
			<tr><td> <a href="AddImage.php">Add Base Image</a></td>
		</table>
<h3 align=left>Class config</h3>
		<table width='90%'>
			<tr><td><a href="AddClass.php">Define Class</a></td>
			<tr><td><a href="Start.php">Create Section</a></td>
			<tr><td><a href="DelClass.php">Delete Section</a></td>
			<tr><td><a href="SelectRestorePoint.php">Restore Section</a></td>
		</table>
<h3 align=left>Config Maintance</h3>
		<table width='90%'>
			<tr><td><a href="sConfigs.php">Show Config</a></td>
			<tr><td><a href="Configs.php">Delete Config</a></td>
		</table>
<?php include('vlab-footer.inc'); ?>
