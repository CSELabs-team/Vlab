<?php
interface UserAuthenticator{
  public function getUserPass( $username );
}
?>