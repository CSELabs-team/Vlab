#!/bin/bash

if [ $# -ne 1 ]
then
   echo "USAGE: $0 <vm image to move>"
   exit;
fi

# list all the xen nodes below 
servers=("vlab-bld-x1" "vlab-bld-y1" "vlab-bld-y2");

for blade in "${servers[@]}" 
do
   echo "Moving to $blade";
   scp $1 root@$blade:/home/local_blade/OS_images/ 
done
