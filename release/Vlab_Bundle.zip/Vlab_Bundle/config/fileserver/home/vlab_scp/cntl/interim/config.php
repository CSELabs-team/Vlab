<?php

$config = array();

$config['xenserver'] = 'vlab-bld-x1';

$config['db_host'] = 'localhost';

//The name of the database
$config['db_name'] = 'vlab';

$config['db_user'] = 'postgres';

$config['db_pass'] = '<YOUR_DB_PASS>';



?>
